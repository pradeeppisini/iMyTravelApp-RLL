package com.mphasis.mytravel.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.mytravel.model.TravelExperience;
import com.mphasis.mytravel.repository.TravelExperienceRepository;

import java.util.List;

@Service
public class TravelExperienceService {
    private final TravelExperienceRepository travelExperienceRepository;

    @Autowired
    public TravelExperienceService(TravelExperienceRepository travelExperienceRepository) {
        this.travelExperienceRepository = travelExperienceRepository;
    }

    public List<TravelExperience> getAllTravelExperiences() {
        return travelExperienceRepository.findAll();
    }

    public TravelExperience getTravelExperienceById(Long id) {
        return travelExperienceRepository.findById(id).orElse(null);
    }

    public TravelExperience saveTravelExperience(TravelExperience travelExperience) {
        return travelExperienceRepository.save(travelExperience);
    }

    public void deleteTravelExperience(Long id) {
        travelExperienceRepository.deleteById(id);
    }
}
