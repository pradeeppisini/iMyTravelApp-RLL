package com.mphasis.mytravel.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.mphasis.mytravel.model.PlaceSuggestion;
import com.mphasis.mytravel.service.PlaceSuggestionService;

import java.util.List;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("/api/place-suggestions")
public class PlaceSuggestionController {

    private final PlaceSuggestionService placeSuggestionService;

    @Autowired
    public PlaceSuggestionController(PlaceSuggestionService placeSuggestionService) {
        this.placeSuggestionService = placeSuggestionService;
    }

    @GetMapping
    public List<PlaceSuggestion> getAllPlaceSuggestions() {
        return placeSuggestionService.getAllPlaceSuggestions();
    }

    @GetMapping("/{id}")
    public PlaceSuggestion getPlaceSuggestionById(@PathVariable Long id) {
        return placeSuggestionService.getPlaceSuggestionById(id);
    }

    @PostMapping
    public PlaceSuggestion createPlaceSuggestion(@RequestBody PlaceSuggestion placeSuggestion) {
        return placeSuggestionService.savePlaceSuggestion(placeSuggestion);
    }

    @PutMapping("/{id}")
    public PlaceSuggestion updatePlaceSuggestion(@PathVariable Long id, @RequestBody PlaceSuggestion placeSuggestion) {
        placeSuggestion.setId(id);
        return placeSuggestionService.savePlaceSuggestion(placeSuggestion);
    }

    @DeleteMapping("/{id}")
    public void deletePlaceSuggestion(@PathVariable Long id) {
        placeSuggestionService.deletePlaceSuggestion(id);
    }
}
