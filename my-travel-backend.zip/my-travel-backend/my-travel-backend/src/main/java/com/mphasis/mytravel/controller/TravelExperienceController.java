package com.mphasis.mytravel.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.mphasis.mytravel.model.TravelExperience;
import com.mphasis.mytravel.service.TravelExperienceService;

import java.util.List;
@CrossOrigin(origins="*")
@RestController
@RequestMapping("/api/travel-experiences")
public class TravelExperienceController {

    private final TravelExperienceService travelExperienceService;

    @Autowired
    public TravelExperienceController(TravelExperienceService travelExperienceService) {
        this.travelExperienceService = travelExperienceService;
    }

    @GetMapping
    public List<TravelExperience> getAllTravelExperiences() {
        return travelExperienceService.getAllTravelExperiences();
    }

    @GetMapping("/{id}")
    public TravelExperience getTravelExperienceById(@PathVariable Long id) {
        return travelExperienceService.getTravelExperienceById(id);
    }

    @PostMapping
    public TravelExperience createTravelExperience(@RequestBody TravelExperience travelExperience) {
        return travelExperienceService.saveTravelExperience(travelExperience);
    }

    @PutMapping("/{id}")
    public TravelExperience updateTravelExperience(@PathVariable Long id, @RequestBody TravelExperience travelExperience) {
        travelExperience.setId(id);
        return travelExperienceService.saveTravelExperience(travelExperience);
    }

    @DeleteMapping("/{id}")
    public void deleteTravelExperience(@PathVariable Long id) {
        travelExperienceService.deleteTravelExperience(id);
    }
}
